#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <error.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <fcntl.h>

#define MAXCONN 99999

int sk1, sk2;
int clients[MAXCONN];




void receiveData(int client, int server) {
    char buffer[99999];
    ssize_t rcvd, sent;

    if((rcvd = recv(server, buffer, 99999, 0)) > 0) {
        sent = send(clients[client], buffer, rcvd, 0);
        printf("BYTES RECEIVED FROM HOST REPLY: %ld\n", sent); }
    else {
        if(rcvd < 0) {
            perror("RECEIVING FROM SERVER\n");
            exit(1); }
        else if(sent < 0) {
            perror("SENDING TO CLIENT\n");
            exit(1); }}}




int clientSocket(char *host) {
    struct sockaddr_in server_addr;
    struct hostent *server;
    int sckt;

    if((sckt = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Client socket\n");
        exit(1); }

    server = gethostbyname(host);
    if(server == NULL) {
        perror("Client host\n");
        exit(1); }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    memcpy(&server_addr.sin_addr.s_addr, server->h_addr, server->h_length);
    server_addr.sin_port = htons(80);

    if(connect(sckt, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        printf("Connecting to client socket: %s\n", strerror(errno));
        exit(1); }

    return sckt; }




void forwardData(int server, char *message) {
    char buffer[99999];
    ssize_t sent;
    //printf("%s", message);

    if((sent = send(server, message, strlen(message), 0)) <= 0)
        fprintf(stderr, "SIZE OF CLIENT REQUEST: %s\n", strerror(errno));
    else printf("BYTES SENT TO SERVER FROM CLIENT REQUEST: %ld\n", sent); }




void processClient(int clientNo) {
    char msgBuff[99999], *requestLine[3], tempBuff[99999];
    int rcvd;
    struct hostent *host_struct;

    memset((void *)msgBuff, (int)'\0', 99999);
    memset((void *)tempBuff, (int)'\0', 99999);

    rcvd = recv(clients[clientNo], msgBuff, 99999, 0);
    strcpy(tempBuff, msgBuff);

    if(rcvd < 0) fprintf(stderr,"Error in receive: %d\n", rcvd);
    else {
        requestLine[0] = strtok(tempBuff, " \t\n");
        if(strncmp(requestLine[0], "GET\0", 4) == 0) {
            //printf("Message received from client %d:\n%s", clientNo, msgBuff);

            requestLine[1] = strtok(NULL, "//");
            requestLine[2] = strtok(NULL, "/");
            //printf("Requested host: %s\n", requestLine[2]);

            char host[strlen(requestLine[2])];
            strcpy(host, requestLine[2]);

            host_struct = gethostbyname(host);
            if(host_struct != NULL){
                printf("\n**Host found at %s**\n**Forwarding message to host...**\n\n", host);

                if((sk2 = clientSocket(host)) <= 0) {
                    perror("Cannot connect to host\n");
                    exit(1); }

                //if(fork() == 0)
                    forwardData(sk2, msgBuff);
                //if(fork() == 0)
                    receiveData(clientNo, sk2);  }

            else write(clients[clientNo], "HTTP/1.0 400 Bad Request\n", 25); }

        else write(clients[clientNo], "HTTP/1.0 400 Bad Request\n", 25);

        shutdown(clients[clientNo], SHUT_RDWR);
        shutdown(sk2, SHUT_RDWR);
        close(sk2);
        close(clients[clientNo]);
        clients[clientNo] = -1; }}




int serverSocket(int port) {
    int sockfd;
    struct sockaddr_in server_addr;

    if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Server socket");
        exit(1); }
    else printf("\n\n****Creating proxy server on port %d****\n\n\n", port);

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    int optval = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR,
      (const void *)&optval , sizeof(int));

    if(bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) != 0) {
        perror("Bind on server socket");
        exit(1); }

    if(listen(sockfd, 100) < 0) {
        perror("Listen on server socket: "); }

    return sockfd; }




int main(int argc, char *argv[]) {
    int port, clientNo = 0;
    port = atoi(argv[1]);
    struct sockaddr_in client_addr;
    socklen_t addrlen = sizeof(client_addr);

    for(int i = 0; i < MAXCONN; i++)
        clients[i] = -1;

    if((sk1 = serverSocket(port)) < 0) {
        perror("Cannot start server\n");
        exit(1); }

    while(1) {
        clients[clientNo] = accept(sk1, (struct sockaddr *)&client_addr, &addrlen);

        if(clients[clientNo] < 0)
            perror("Accept\n");
        else {
            if(fork() == 0) {
                processClient(clientNo);
                exit(0); }}

        while(clients[clientNo] != -1) clientNo = (clientNo + 1) % MAXCONN; }

    return 0; }
