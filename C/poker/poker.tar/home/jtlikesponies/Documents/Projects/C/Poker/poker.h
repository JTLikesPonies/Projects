struct Card {
    int suit;
    int rank;
    int num; };


extern struct Card deck[52];
extern struct Card hole[2];
extern struct Card community[5];
